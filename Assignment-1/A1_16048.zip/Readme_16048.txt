# Kaustav Vats (2016048)

Q-How to run these programs?

1. In terminal type 'make -f Makefile_16048' to compile all C files.
2. create n+1 terminals. n clients and 1 server.
3. First start the server by entering './server'
3. To create a client, in each terminal enter './client'
4. In each client enter the name then, type a message to broadcast.
5. Enter 'exit' to close a client or a server. Press CTRL+C to abruptly close a client or server.

Q-How to remove Object files of the program?
A-Enter 'make -f Makefile_16048 clean' to remove client and server(object) files.